#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <sys/wait.h>
#include <time.h>
#include <pthread.h>

#define MAX_PROCESSES 64

int temp[MAX_PROCESSES*2];
int num_index=0;
pthread_mutex_t counter_mutex = PTHREAD_MUTEX_INITIALIZER;

// start function of thread
int adding(void * arg)
{
	pthread_mutex_lock(&counter_mutex); // synchroniz
	int result = temp[2*num_index]+temp[2*num_index+1];
	num_index++;
	pthread_mutex_unlock(&counter_mutex); // synchronize
	
	return result;
}

void main()
{
	pthread_t tid[MAX_PROCESSES];
	
	char temp_line[10]; // line of temp file

	struct timespec tstart={0,0}, tend={0,0};
	
	FILE * read_temp;
	
	char arg[10];
	
	int asd;
	
	// file open.
	read_temp = fopen("temp.txt","r");
	if (read_temp == NULL)
	{
		puts("file open error");
		return;
	}
	else
	{
		// read file to temp array.
		for(int a=0; a<MAX_PROCESSES*2; a++)
		{
			fgets(temp_line, sizeof(char)*10, read_temp);
			
			temp[a] = atoi(temp_line);
		}
	}
	fclose(read_temp);
	
	clock_gettime(CLOCK_MONOTONIC, &tstart); // start timer

	for(int a=MAX_PROCESSES; a>0; a=a/2)
	{
		num_index=0;
		for(int i=0; i< a; i++)
		{
			pthread_create(&tid[i], NULL, (void *)adding, NULL); // make thread start function : adding
		}
		
		for(int i=0; i<a; i++)
		{
			pthread_join(tid[i], (void **)&temp[i]); // wait for termination of thread
		}
	}
	
	clock_gettime(CLOCK_MONOTONIC, &tend); // end timer
	
	printf("value of fork : %d\n", temp[0]);
	printf("%.6f\n", ((double)tend.tv_sec + 1.0e-9*tend.tv_nsec)-((double)tstart.tv_sec + 1.0e-9*tstart.tv_nsec) );
	
	return;
}