#include <linux/module.h>
#include <linux/highmem.h>
#include <linux/kallsyms.h>
#include <linux/syscalls.h>
#include <asm/syscall_wrapper.h>

// system call add's table number.
#define __NR_add 549

void **syscall_table; // store current system call's address

void *real_add;

__SYSCALL_DEFINEx(2, mul, int, a, int, b) // subtitute existing system call
{
	long result;

	result = a * b; // multiply

	return result;
}

void make_rw(void *addr) // give permission (read,write authority of *addr's page)
{
	unsigned int level;
	pte_t *pte = lookup_address((u64)addr, &level); // addr in memory, level of the mapping

	if(pte->pte &~ _PAGE_RW) // if no permission,
		pte->pte |= _PAGE_RW; // give that.
}

void make_ro(void *addr) // recover permission (read,write authority of *addr's page)
{
	unsigned int level;
	pte_t *pte = lookup_address((u64)addr, &level); // addr in memory, level of the mapping

	pte->pte = pte->pte &~ _PAGE_RW; // recover permission
}

static int __init wrraping_init(void) { // when module embarked, do it
	printk(KERN_INFO "init_[2015722087]\n"); // print my id

	syscall_table = (void**) kallsyms_lookup_name("sys_call_table"); // find system call table

	make_rw(syscall_table); // give permission

	real_add = syscall_table[__NR_add]; // store current system call address

	syscall_table[__NR_add] = __x64_sys_mul; // change system call to sys_mul
	
	return 0;
}

static void __exit wrraping_exit(void) { // when module relieve, do it
	printk(KERN_INFO "exit_[2015722087]\n"); // print my id

	syscall_table[__NR_add] = real_add; // recover system call to sys_add

	make_ro(syscall_table); // recover permission
}

module_init(wrraping_init);
module_exit(wrraping_exit);
MODULE_LICENSE("GPL");
