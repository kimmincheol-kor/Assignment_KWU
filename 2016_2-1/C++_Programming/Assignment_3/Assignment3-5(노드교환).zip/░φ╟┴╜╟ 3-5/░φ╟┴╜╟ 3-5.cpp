#include "list.h"

int main()
{
	list List;
	char arr[100], chs;
	int row, col;
	ifstream fin;
	fin.open("puzzle.txt");
	if (!fin)
	{
		cout << "File opne error" << endl;
		return 0;
	}
	fin >> arr;
	row = atoi(strtok(arr, "X"));
	col = atoi(strtok(NULL, "X"));
	List.Insert(row, col);//���� �����

	fin >> arr;
	for (int i = 0; *(arr + i) != '\0'; i++)
		List.Quiz(*(arr + i));//���� ����
	fin.close();
	List.Print();

	while (1)
	{
		cout << "---------------------------------------"<<endl;
		cout << endl << "�Է� : ";
		cin >> chs;
		cout << endl;
		List.Quiz(chs);
		List.Print();
		if (List.Check() == 1)
		{
			cout << "Quiz Complete!" << endl;
			break;
		}
	}

	return 0;
}