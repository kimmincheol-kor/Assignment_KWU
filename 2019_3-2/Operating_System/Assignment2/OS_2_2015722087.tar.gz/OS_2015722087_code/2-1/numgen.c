#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>

#define MAX_PROCESSES 64

void main()
{
	FILE * write_temp;
	
	write_temp = fopen("temp.txt","w"); // open file to write
	
	for(int i=0; i<MAX_PROCESSES*2; i++)
	{
		fprintf(write_temp, "%d\n", i+1); // write i+1 to file
	}
	
	fclose(write_temp); // close the opened file

	return;
}