#include <stdio.h>

#define len_M 7
#define len_N 6

// function of compute LCS
void LCS(char str1[], char str2[], int i, int j);
void find_LCS(char str[]);

// space for store compute
int space[len_N + 1][len_M + 1] = { NULL, };

void main()
{
	// two sequence
	char array_x[len_M] = { 'a','b','c','b','d','a','b' };
	char array_y[len_N] = { 'b','d','c','a','b', 'a' };

	printf("Bottom Up LCS ALGO\n\n");

	// set 0 line to zero.
	for (int a = 0; a <= len_M; a++)
	{
		space[0][a] = 0;
	}
	for (int b = 0; b <= len_N; b++)
	{
		space[b][0] = 0;
	}

	// Compute !
	LCS(array_x, array_y, len_M, len_N);

	// print space
	printf("Table\n    ");

	for (int a = 0; a < len_M; a++)
	{
		printf("%c ", array_x[a]);
	}
	printf("\n");

	for (int a = 0; a < len_N + 1; a++) // column : array y
	{
		if (a != 0)
			printf("%c ", array_y[a - 1]);
		else
			printf("  ");
		for (int b = 0; b < len_M + 1; b++) // row : array x
		{
			printf("%d ", space[a][b]);
		}
		printf("\n");
	}

	// print LCS
	printf("\nLength of LCS = %d\n\n", space[len_N][len_M]);

	// find lcs of x and b
	find_LCS(array_y);
}

void LCS(char str1[], char str2[], int i, int j)
{
	for (int a = 0; a < j; a++) // column element : array y
	{
		for (int b = 0; b < i; b++) // row element : array x
		{
			if (str1[b] == str2[a]) // if same, store previous data + 1 
				space[a + 1][b + 1] = space[a][b] + 1;
			else // if different, store max of above data, left data
				space[a + 1][b + 1] = space[a][b + 1] > space[a + 1][b] ? space[a][b + 1] : space[a + 1][b];

		}
	}
}

void find_LCS(char str[]) // find sequnce of lcs
{
	// index of column, row
	int a = len_N;
	int b = len_M;

	// itertor of finding
	int iterator = space[a][b];

	// string of sequence of lcs
	char lcs[1000];

	// find !
	while (1)
	{
		if (iterator == 0) // end of finding
		{
			printf("\n\nEnd!!\n\n");
			lcs[space[len_N][len_M]] = '\0'; // end of string
			break;
		}

		if (iterator == space[a][b - 1]) // move left
		{
			printf("Move Left!! %d -> %d\n", iterator, space[a][b - 1]);
			iterator = space[a][b - 1];
			b--;
		}
		else if (iterator == space[a - 1][b]) // move up
		{
			printf("Move Up!! %d -> %d\n", iterator, space[a-1][b]);
			iterator = space[a - 1][b];
			a--;
		}
		else if (iterator == space[a - 1][b - 1] + 1) // move to diagonal
		{
			printf("Move diagonal!! %d -> %d\n", iterator, space[a-1][b - 1]);
			printf("find : %c\n", str[a - 1]);

			lcs[iterator - 1] = str[a - 1]; // input value to sequnce of lcs

			iterator = space[a - 1][b - 1];

			a--;
			b--;
		}

	}

	// Print sequence of lcs
	printf("LCS : %s\n", lcs);

	return;
}