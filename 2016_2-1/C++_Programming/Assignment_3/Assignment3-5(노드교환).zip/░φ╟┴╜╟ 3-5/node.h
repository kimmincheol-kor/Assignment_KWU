#pragma once
#include <fstream>
#include<iostream>
using namespace std;

class node
{
	int data;
	node * pUp, * pDown, * pLeft, * pRight;
public:
	node();
	~node();

	void setData(int num);
	void setUp(node *pNode);
	void setDown(node *pNode);
	void setLeft(node *pNode);
	void setRight(node *pNode);
	int getData();
	node * getUp();
	node * getDown();
	node * getLeft();
	node * getRight();
};

