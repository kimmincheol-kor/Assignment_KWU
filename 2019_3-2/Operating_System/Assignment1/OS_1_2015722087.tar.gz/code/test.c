#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <unistd.h>
#include <sys/syscall.h>

int main(int argc, char *argv[]) // test program main func.
{
	int a,b; // two parameter
	long result; // result

	if(argc != 3) // parameter number is must 3
	{
		printf("\n\nPARAMETER ERROR : %d\n\n", argc);
		return 0;
	}

	a = atoi(argv[1]); // a = parameter 1
	b = atoi(argv[2]); // b = parameter 2

	result = syscall(549, a, b); // system call table number 549 function
	
	printf("%d op. %d = %ld\n", a, b, result); // print result

	return 0;
}
