//package "your_project_name";

public class BookNode{
	private String title;	//Book name;
	private String author;	//Book author;
	
	public BookNode() {
		
	}
	public void setTitle(String title) {

	}
	public void setAuthor(String author) {
		
	}
	public String getTitle() {
		
	}
	public String getAuthor() {
	
	}

}
