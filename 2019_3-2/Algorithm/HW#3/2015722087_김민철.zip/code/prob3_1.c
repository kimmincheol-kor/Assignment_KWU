#include <stdio.h>

#define len_M 7
#define len_N 6

// function for compute length of lcs
int LCS(char str1[], char str2[], int i, int j);

// space for store lcs
int space[len_M][len_N] = {0,};

// number of do computing
int num_do;

void main()
{
	// reset num_do
	num_do = 0;

	// two sequence
	char array_x[len_M] = { 'a','b','c','b','d','a','b' };
	char array_y[len_N] = { 'b','d','c','a','b', 'a' };

	printf("Top Down LCS ALGO\n\n");
	
	// start computing LCS of x and y
	space[len_M - 1][len_N - 1] = LCS(array_x, array_y, len_M - 1, len_N - 1);

	printf("Length of LCS = %d\ntheta of time : %d\n", space[len_M - 1][len_N - 1] - 1, num_do);
}

int LCS(char str1[], char str2[], int i, int j)
{
	// print start of computing
	printf("start of compute LCS( x, y, %d, %d ), x[i] = %c , y[j] = %c\n\n", i, j, str1[i], str2[j]);

	// clean warning of i, j
	int clean_M = len_M - i;
	int clean_N = len_N - j;

	// stroe result
	int result;

	if (space[i][j] == 0) // first compute
	{
		num_do++; // do computing => num_do ++

		if (str1[i] == str2[j]) // LCS = LCS(i-1,j-1) + 1
		{
			if (i > 0 && j > 0) // both are longer than 1
				space[i][j] = LCS(str1, str2, i - 1, j - 1) + 1;
			else // at least one array have only one element
				space[i][j] = 2;

			result = space[i][j];
		}
		else // LCS = MAX( LCS(i-1,j), LCS(i,j-1) )
		{
			if (i > 0) // if i-1 >= 0
				space[i - 1][j] = LCS(str1, str2, i - 1, j);

			if (j > 0) // if j-1 >= 0
				space[i][j - 1] = LCS(str1, str2, i, j - 1);

			if (i == 0 && j == 0) // if i==0, j==0
				space[i][j] = 1;

			if (i > 0 && j > 0) // both are  >= 1
			{
				if (space[len_M - clean_M - 1][len_N - clean_N] > space[len_M - clean_M][len_N - clean_N - 1])
					result = space[len_M - clean_M - 1][len_N - clean_N];
				else
					result = space[len_M - clean_M][len_N - clean_N - 1];
			}
			else if (i > 0 && j == 0)  // only i-1 >= 0
			{
				if (space[len_M - clean_M - 1][len_N - clean_N] > space[len_M - clean_M][len_N - clean_N])
					result = space[len_M - clean_M - 1][len_N - clean_N];
				else
					result = space[len_M - clean_M][len_N - clean_N];
			}
			else if (j > 0 && i == 0) // only j-1 >= 0
			{
				if (space[len_M - clean_M][len_N - clean_N] > space[len_M - clean_M][len_N - clean_N - 1])
					result = space[len_M - clean_M][len_N - clean_N];
				else
					result = space[len_M - clean_M][len_N - clean_N - 1];
			}
			else // both are 0
				result = 1;
				
		}
	}
	else // exist same compute result => do not compute
	{
		return space[i][j];
	}

	// print both array
	for (int z = 0; z < 2; z++)
	{
		if (z == 0)
		{
			printf("Array X : ");

			for (int a = 0; a <= i; a++)
			{
				printf("%c ", str1[a]);
			}
		}
		else
		{
			printf("Array Y : ");

			for (int a = 0; a <= j; a++)
			{
				printf("%c ", str2[a]);
			}
		}

		printf("\n");
	}

	// print result of computing
	printf("result of compute i = %d, j = %d   x[i] = %c, y[j] = %c\nLCS(x, y, i, j) = %d\n\n", i, j, str1[i], str2[j], result-1);

	// store result
	space[len_M - clean_M][len_N - clean_N] = result;

	return result;
}