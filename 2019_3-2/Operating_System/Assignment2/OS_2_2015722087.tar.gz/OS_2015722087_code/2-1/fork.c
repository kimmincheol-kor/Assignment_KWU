#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <time.h>
#include <stdlib.h>
#include <semaphore.h>

#define MAX_PROCESSES 64

sem_t mysem;

int temp[MAX_PROCESSES*2]; // store value of temp file

// main function of child
int adding(int i)
{
	sem_wait(&mysem); // wait for get sem
	int result = temp[2*i]+temp[2*i+1];
	sem_post(&mysem); // post sem
	
	return result;
}

void main()
{
	pid_t pid[MAX_PROCESSES]; // store child pid
	
	char temp_line[10]; // line of temp file
	
	struct timespec tstart={0,0}, tend={0,0}; // measure running time
	
	FILE * read_temp;
	
	// file open.
	read_temp = fopen("temp.txt","r");
	if (read_temp == NULL)
	{
		puts("file open error");
		return;
	}
	else
	{
		// read file to temp array.
		for(int a=0; a<MAX_PROCESSES*2; a++)
		{
			fgets(temp_line, sizeof(char)*10, read_temp);
			
			temp[a] = atoi(temp_line);
		}
	}
	fclose(read_temp);
	
	sem_init(&mysem, 0, 1); // initialize semaphore
	
	clock_gettime(CLOCK_MONOTONIC, &tstart); // start timer

	for(int a=MAX_PROCESSES; a>=1; a=a/2) // a, a/2, a/2/2, a/2/2/2 ....
	{
		for(int i=0; i< a; i++)
		{
			pid[i] = fork(); // fork !!
			if (pid[i] == 0) // child
			{
				int result = adding(i); // adding is main function of child
				exit(result); // termination of child
			}
		}
		
		for(int i=0; i<a; i++) // wait.
		{
			waitpid(pid[i], &temp[i], 0);
			temp[i] = temp[i]/256;
		}
	}
	
	clock_gettime(CLOCK_MONOTONIC, &tend); // end timer
	
	printf("value of fork : %d\n", temp[0]); // print result.
	printf("%.6f\n", ((double)tend.tv_sec + 1.0e-9*tend.tv_nsec)-((double)tstart.tv_sec + 1.0e-9*tstart.tv_nsec) ); // print timer time
	
	return;
}