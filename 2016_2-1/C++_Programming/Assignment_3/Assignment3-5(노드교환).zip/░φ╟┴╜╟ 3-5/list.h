#pragma once
#include "node.h"

class list
{
private:
	node * pPoint;
public:
	list();
	~list();

	void Insert(int row, int col);
	void Quiz(char quiz);
	void Print();
	bool Check();
};

