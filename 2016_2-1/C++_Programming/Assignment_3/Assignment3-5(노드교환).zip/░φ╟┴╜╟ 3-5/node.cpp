#include "node.h"



node::node()
{
	data = 0;
	pUp = pDown = pLeft = pRight = nullptr;
}


node::~node()
{
}

void node::setData(int num)
{
	data = num;
}

void node::setUp(node *pNode)
{
	pUp = pNode;
}

void node::setDown(node *pNode)
{
	pDown = pNode;
}

void node::setLeft(node *pNode)
{
	pLeft = pNode;
}

void node::setRight(node *pNode)
{
	pRight = pNode;
}

int node::getData()
{
	return data;
}

node * node::getUp()
{
	return pUp;
}

node * node::getDown()
{
	return pDown;
}

node * node::getLeft()
{
	return pLeft;
}

node * node::getRight()
{
	return pRight;
}
