#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <time.h>
#include <stdlib.h>
#include <sched.h>
#include <sys/resource.h>
#include <sys/stat.h>

#define MAX_PROCESSES 10000

int temp[MAX_PROCESSES];

void main()
{
	struct timespec tstart={0,0}, tend={0,0}; // measure running time
	pid_t pid[MAX_PROCESSES]; // store child pid
	
	struct sched_param sp; // schedule parameter struct
	
	FILE * read_file;
	char file_name[100];
	char file_line[10];
	
	int status;
	double total_time=0.0;
	
	for(int a=0; a<9; a++)
	{
		//////////////// SCHED_OTHER
		if(a==0)
		{
			nice(20); // lowest priority
			printf("Scheduler type : SCHED_OTHER	nice : 20\n");
		}
		else if(a==1)
		{
			// default priority
			printf("Scheduler type : SCHED_OTHER	nice : default\n");
		}
		else if(a==2)
		{
			nice(-20); // higher priority
			printf("Scheduler type : SCHED_OTHER	nice : -20\n");
		}
		/////////////////////////////////
		
		//////////////// SCHED_FIFO
		else if(a==3)
		{
			sp.sched_priority=1; // lowest priority
			printf("Scheduler type : SCHED_FIFO	Priority : lowest\n");
		}
		else if(a==4)
		{
			sp.sched_priority=50; // middle priority
			printf("Scheduler type : SCHED_FIFO	Priority : middle\n");
		}
		else if(a==5)
		{
			sp.sched_priority=99; // highest priority
			printf("Scheduler type : SCHED_FIFO	Priority : highest\n");
		}
		///////////////////////////////////
		
		//////////////// SCHED_RR
		else if(a==6)
		{
			sp.sched_priority=1; // lowest priority
			printf("Scheduler type : SCHED_RR	Priority : lowest\n");
		}
		else if(a==7)
		{
			sp.sched_priority=50; // middle priority
			printf("Scheduler type : SCHED_RR	Priority : middle\n");
		}
		else if(a==8)
		{
			sp.sched_priority=99; // highest priority
			printf("Scheduler type : SCHED_RR	Priority : highest\n");
		}
		///////////////////////////////////
		
		for(int k=0; k<10; k++)
		{
			clock_gettime(CLOCK_MONOTONIC, &tstart); // start timer
			
			for(int i=0; i<MAX_PROCESSES; i++) // make child, read files
			{
				pid[i] = fork(); // fork !!
				
				if(pid[i] < 0) // error
				{
					printf("ERROR : fork()\n");
					return;
				}
				else if(pid[i] == 0) // child
				{
					if(a<3) // SCHED_OTHER
						sched_setscheduler(getpid(), SCHED_OTHER, &sp);
					else if(a<6) // SCHED_FIFO
						sched_setscheduler(getpid(), SCHED_FIFO, &sp);
					else if(a<9) // SCHED_RR
						sched_setscheduler(getpid(), SCHED_RR, &sp);
					
					chdir("temp"); // change directory to temp.
					sprintf(file_name, "%d", i); // file_name = i
					read_file = fopen(file_name, "r"); // read file.
					
					fgets(file_line, sizeof(char)*10, read_file); // get line of file
					
					temp[i] = atoi(file_line); // input to temp array.
					
					fclose(read_file); // close file
					
					exit(0); // termination of child
				}
			}
			
			clock_gettime(CLOCK_MONOTONIC, &tend); // end timer
			
			for(int i=0; i<MAX_PROCESSES; i++) // wait.
			{
				waitpid(pid[i], &status, 0);
			}
			
			// print running time
			printf("Running time : %.6f\n", ((double)tend.tv_sec + 1.0e-9*tend.tv_nsec)-((double)tstart.tv_sec + 1.0e-9*tstart.tv_nsec) ); // print timer time
			total_time += ((double)tend.tv_sec + 1.0e-9*tend.tv_nsec)-((double)tstart.tv_sec + 1.0e-9*tstart.tv_nsec);
		}
		
		// print average time
		printf("Average time = %.6f\n\n", total_time/10.0);
		total_time = 0.0;
	}
	
	return;
}