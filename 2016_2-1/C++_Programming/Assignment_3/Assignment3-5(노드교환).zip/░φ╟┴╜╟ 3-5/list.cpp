#include "list.h"



list::list()
{
	pPoint = nullptr;
}


list::~list()
{
	node * pCur1 = pPoint;
	node * pCur2;
	while (pCur1->getLeft())
		pCur1 = pCur1->getLeft();
	while (pCur1->getUp())
		pCur1 = pCur1->getUp();
	while (pPoint)
	{
		pPoint = pCur1->getDown();
		while (pCur1)
		{
			pCur2 = pCur1;
			pCur1 = pCur1->getRight();
			delete pCur2;
		}
		pCur1 = pCur2 = pPoint;
	}
}

void list::Insert(int row, int col)
{
	node  * pCur1, * pCur2;
	node * pNew;
	int num = 0;
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)//row ��ŭ ���μ�ġ
		{
			pNew = new node;
			pNew->setData(num++);
			if (i == 0 && j == 0)
				pPoint = pNew;
			else if (j == 0)
			{
				pCur1 = pPoint;
				while (pCur1->getDown() != nullptr)
					pCur1 = pCur1->getDown();
				pCur1->setDown(pNew);
				pNew->setUp(pCur1);
			}
			else
			{
				pCur1 = pPoint;
				while (pCur1->getDown() != nullptr)
					pCur1 = pCur1->getDown();
				pCur2 = pCur1;
				while (pCur2->getRight() != nullptr)
					pCur2 = pCur2->getRight();
				pCur2->setRight(pNew);
				pNew->setLeft(pCur2);
			}
		}
		if (i != 0)//���� ����
		{
			pCur1 = pPoint;
			pCur2 = pPoint->getDown();
			for (int j = 1; j < i; j++)
			{
				pCur1 = pCur1->getDown();
				pCur2 = pCur2->getDown();
			}
			while (pCur1)
			{
				pCur1->setDown(pCur2);
				pCur2->setUp(pCur1);
				pCur1 = pCur1->getRight();
				pCur2 = pCur2->getRight();
			}
		}
	}
}

void list::Quiz(char quiz)
{
	if (quiz == 'u' || quiz == 'd')
	{
		if (quiz == 'd' && pPoint->getDown() == nullptr)
			return;
		if (quiz == 'd')
			pPoint = pPoint->getDown();
		if (pPoint->getUp() != nullptr)
		{
			if (pPoint->getLeft() != nullptr)
			{
				pPoint->getUp()->getLeft()->setRight(pPoint);
				pPoint->getLeft()->setRight(pPoint->getUp());
				pPoint->getUp()->setLeft(pPoint->getLeft());
				pPoint->setLeft(pPoint->getLeft()->getUp());
			}
			if (pPoint->getDown() != nullptr)
			{
				pPoint->getDown()->setUp(pPoint->getUp());
				pPoint->getUp()->setDown(pPoint->getDown());
			}
			else
			{
				pPoint->getUp()->setDown(nullptr);
			}
			if (pPoint->getRight() != nullptr)
			{
				pPoint->getUp()->getRight()->setLeft(pPoint);
				pPoint->getRight()->setLeft(pPoint->getUp());
				pPoint->getUp()->setRight(pPoint->getRight());
				pPoint->setRight(pPoint->getRight()->getUp());
			}
			if (pPoint->getUp()->getUp() != nullptr)
			{
				pPoint->getUp()->getUp()->setDown(pPoint);
				pPoint->setUp(pPoint->getUp()->getUp());
			}
			else
			{
				pPoint->setUp(nullptr);
			}
			if (pPoint->getDown() == nullptr)
			{
				if (pPoint->getLeft() == nullptr)
				{
					pPoint->setDown(pPoint->getRight()->getDown()->getLeft());
					pPoint->getDown()->setUp(pPoint);
				}
				else
				{
					pPoint->setDown(pPoint->getLeft()->getDown()->getRight());
					pPoint->getDown()->setUp(pPoint);
				}
			}
			else
			{
				pPoint->getDown()->getUp()->setUp(pPoint);
				pPoint->setDown(pPoint->getDown()->getUp());
			}

		}
		if (quiz == 'd')
			pPoint = pPoint->getDown();
	}
	else if (quiz == 'r' || quiz == 'l')
	{
		if (quiz == 'l' && pPoint->getLeft() == nullptr)
			return;
		if (quiz == 'l')
			pPoint = pPoint->getLeft();
		if (pPoint->getRight() != nullptr)
		{
			if (pPoint->getUp() != nullptr)
			{
				pPoint->getRight()->getUp()->setDown(pPoint);
				pPoint->getUp()->setDown(pPoint->getRight());
				pPoint->getRight()->setUp(pPoint->getUp());
				pPoint->setUp(pPoint->getUp()->getRight());
			}
			if (pPoint->getLeft() != nullptr)
			{
				pPoint->getLeft()->setRight(pPoint->getRight());
				pPoint->getRight()->setLeft(pPoint->getLeft());
			}
			else
			{
				pPoint->getRight()->setLeft(nullptr);
			}
			if (pPoint->getDown() != nullptr)
			{
				pPoint->getRight()->getDown()->setUp(pPoint);
				pPoint->getDown()->setUp(pPoint->getRight());
				pPoint->getRight()->setDown(pPoint->getDown());
				pPoint->setDown(pPoint->getDown()->getRight());
			}
			if (pPoint->getRight()->getRight() != nullptr)
			{
				pPoint->getRight()->getRight()->setLeft(pPoint);
				pPoint->setRight(pPoint->getRight()->getRight());
			}
			else
			{
				pPoint->setRight(nullptr);
			}
			if (pPoint->getLeft() == nullptr)
			{
				if (pPoint->getUp() == nullptr)
				{
					pPoint->setLeft(pPoint->getDown()->getLeft()->getUp());
					pPoint->getLeft()->setRight(pPoint);
				}
				else
				{
					pPoint->setLeft(pPoint->getUp()->getLeft()->getDown());
					pPoint->getLeft()->setRight(pPoint);
				}
			}
			else
			{
				pPoint->getLeft()->getRight()->setRight(pPoint);
				pPoint->setLeft(pPoint->getLeft()->getRight());
			}

		}
		if (quiz == 'l')
			pPoint = pPoint->getLeft();
	}
}

void list::Print()
{
	node * pWork = pPoint;
	node * pCur;

	while (pWork->getLeft())
		pWork = pWork->getLeft();
	while (pWork->getUp())
		pWork = pWork->getUp();
	pCur = pWork;
	while (pCur)
	{
		pCur = pCur->getDown();
		while (pWork)
		{
			cout << pWork->getData() << '\t';
			pWork = pWork->getRight();
		}
		cout << endl << endl;
		pWork = pCur;
	}
}

bool list::Check()
{
	int num = 0;
	node * pWork = pPoint;
	node * pCur;

	while (pWork->getLeft())
		pWork = pWork->getLeft();
	while (pWork->getUp())
		pWork = pWork->getUp();
	pCur = pWork;
	while (pCur)
	{
		pCur = pCur->getDown();
		while (pWork)
		{
			if (pWork->getData() != num++)
				return 0;
			pWork = pWork->getRight();
		}
		pWork = pCur;
	}
	return 1;
}