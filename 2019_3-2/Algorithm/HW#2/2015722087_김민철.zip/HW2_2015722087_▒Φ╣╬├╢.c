#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h>

void QuickSort(int array[], int p, int q); // Main Quick Sort : T(n)
void QuickSort_sub(int array[], int p, int q); // Sub Quick Sort : T(n/2), T(n/4)...

boolean flag_rand=0; // flag for randomized quick sort, random input
boolean flag_print=0; // flag for print step by step
boolean flag_best = 0; // flag for best case, pivot = middle value

// using at measure number of comparison, running time
int num_comparison = 0;
double	run_time = 0.0;

// using at average case
int total_comparison = 0;
double total_runtime = 0.0;

void main()
{
	// 3 Arrays for 3 Case
	int worst_array[1000];
	int best_array[1000];
	int random_array[1000];

	int prob_num; // problem number.
	int prob_case; // case number

	// select problem
	printf("Select Number of Problem (2 or 3 or 4) : ");
	scanf_s("%d", &prob_num);

	// select case
	printf("Select Case (1-(a) or 2-(b) or 3-(c)) : ");
	scanf_s("%d", &prob_case);

	printf("\n");

	// make array
	for (int a=0; a < 1000; a++)
	{
		// make for worst case
		worst_array[a] = a+1;

		// make for best case
		best_array[a] = a+1;
	}

	// check best case
	if (prob_case == 2)
		flag_best = 1;
	else
		flag_best = 0;

	// check randomized or not
	if (prob_case == 3)
		flag_rand = 1;
	else
		flag_rand = 0;

	// classify
	switch(prob_num)
	{
		case 2: // step by step
			flag_print = 1;

			if (prob_case == 1)			QuickSort(worst_array, 0, 8);
			else if (prob_case == 2)	QuickSort(best_array, 0, 8);
			else if (prob_case == 3)	QuickSort(random_array, 0, 8);

			break;

		case 3: // print number of comparison
			if (prob_case == 1)
			{
				for (int n = 100; n < 1001; n += 100)
				{
					printf("Number of n : %d\n", n);
					QuickSort(worst_array, 0, n - 1);
					printf("Number of Comparison of a pivot : %d\n\n", num_comparison);
					num_comparison = 0;

				}
			}
			else if (prob_case == 2)
			{
				for (int n = 100; n < 1001; n += 100)
				{
					printf("Number of n : %d\n", n);
					QuickSort(best_array, 0, n - 1);
					printf("Number of Comparison of a pivot : %d\n\n", num_comparison);
					num_comparison = 0;
				}
			}
			else if (prob_case == 3)
			{
				for (int n = 100; n < 1001; n += 200)
				{
					printf("Number of n : %d\n", n);
					for (int a = 0; a < 20; a++)
					{
						QuickSort(random_array, 0, n - 1);
						printf("No.%d	Number of Comparison of a pivot : %d\n", a + 1, num_comparison);
						total_comparison += num_comparison;
						num_comparison = 0;
					}

					printf("\nAverage of Comparison : %d\n\n", total_comparison / 20);

					total_comparison = 0;
				}
			}

			break;

		case 4: // print running time
			if (prob_case == 1)
			{
				for (int n = 100; n < 1001; n += 100)
				{
					printf("Number of n : %d\n", n);
					QuickSort(worst_array, 0, n - 1);
					printf("Actual Running Time : %lf\n\n",run_time);
					run_time = 0.0;
				}
			}
			else if (prob_case == 2)
			{
				for (int n = 100; n < 1001; n += 100)
				{
					printf("Number of n : %d\n", n);
					QuickSort(best_array, 0, n - 1);
					printf("Actual Running Time : %lf\n\n",run_time);
					run_time = 0.0;
				}
			}
			else if (prob_case == 3)
			{
				for (int n = 100; n < 1001; n += 200)
				{
					printf("Number of n : %d\n", n);
					for (int a = 0; a < 20; a++)
					{
						QuickSort(random_array, 0, n - 1);
						printf("No.%d	Actual Running Time : %lf\n", a + 1, run_time);
						total_runtime += run_time;
						run_time = 0.0;
					}

					printf("\nAverage of Run time : %lf\n\n", total_runtime / 20.0);

					total_runtime = 0.0;
				}
			}

			break;

		default:
			printf("ERROR : not 2, 3, 4\n");
			return;
	}

}

void QuickSort(int array[], int p, int q) // Main Quick Sort : make random array, print input array, output array,
{
	int check;
	int random;

	// make random array
	if (flag_rand == 1)
	{
		Sleep(1000);
		srand(time(NULL));
		for (int a = 0; a < 1000; a++)
		{
			check = 0;
			random = rand() % 1000; // random number

			for (int b = 0; b < a; b++) // check duplication
			{
				if (array[b] == random) // duplication condition
					check++;
			}

			if (check != 0) // duplicate
				a--;
			else // not duplicate
				array[a] = random;
		}
	}

	// if problem 2 (step by step), print input array
	if (flag_print == 1)
	{
		printf("Input Array : ");
		for (int i = p; i <= q; i++)
		{
			printf("%d ", array[i]);
		}
		printf("\n\n");
	}

	int pivot;
	int partition;

	int middle;
	int temp;

	if (p < q)
	{
		// set random pivot
		if (flag_rand == 1)
		{
			srand(time(NULL));
			random = (rand() % (q - p)) + p;

			// swap
			temp = array[random];
			array[random] = array[p];
			array[p] = temp;
		}

		// set best pivot(middle value)
		if (flag_best == 1)
		{
			middle = p + ((q - p) / 2);
			if (middle > p)
			{
				temp = array[middle];
				array[middle] = array[p];
				array[p] = temp;
			}
		}

		// Start Quick Sort.
		pivot = array[p];
		partition = p;

		LARGE_INTEGER startT, endT, fre; // check time
		run_time = 0.0;
		QueryPerformanceFrequency(&fre); // frequency.
		QueryPerformanceCounter(&startT); // start time

		// partitioning
		for (int i = p + 1; i <= q; i++)
		{
			num_comparison++;
			if (array[i] < pivot)
			{
				partition++;

				// swap
				temp = array[partition];
				array[partition] = array[i];
				array[i] = temp;
			}
		}

		// dividing by pivot
		temp = array[partition];
		array[partition] = array[p];
		array[p] = temp;

		// if problem 2 (step by step), print Left, Right side
		if (flag_print == 1)
		{
			printf("Pivot : %d\n", pivot);
			printf("Left Side : ");
			for (int a = p; a <= partition - 1; a++)
				printf("%d ", array[a]);

			printf("\nRight Side : ");
			for (int b = partition + 1; b <= q; b++)
				printf("%d ", array[b]);

			printf("\n\n");
		}

		// Recursively Sort -> Sub Quick Sort
		QuickSort_sub(array, p, partition - 1);
		QuickSort_sub(array, partition + 1, q);

		QueryPerformanceCounter(&endT); // end time
		
		run_time  = (double)(endT.QuadPart - startT.QuadPart) / fre.QuadPart;

		// if problem 2 (step by step), print Result
		if (flag_print == 1)
		{
			printf("Result Array : ");
			for (int i = p; i <= q; i++)
			{
				printf("%d ", array[i]);
			}
			printf("\n\n");
		}
	}

	return;
}

void QuickSort_sub(int array[], int p, int q) // Sub Quick Sort. -> Just Sort only
{
	int pivot;
	int partition;

	int temp;
	int random;
	int middle;

	if (p < q)
	{
		// set random pivot
		if (flag_rand == 1)
		{
			srand(time(NULL));
			random = (rand() % (q - p)) + p;

			// swap
			temp = array[random];
			array[random] = array[p];
			array[p] = temp;
		}

		// set best pivot(middle value)
		if (flag_best == 1)
		{
			middle = p + ((q - p) / 2);
			if ( middle > p )
			{
				temp = array[middle];
				array[middle] = array[p];
				array[p] = temp;
			}
		}

		pivot = array[p];
		partition = p;

		for (int i = p + 1; i <= q; i++)
		{
			num_comparison++;
			if (array[i] < pivot)
			{
				partition++;

				// swap
				temp = array[partition];
				array[partition] = array[i];
				array[i] = temp;
			}
		}

		// swap
		temp = array[partition];
		array[partition] = array[p];
		array[p] = temp;

		if (flag_print == 1)
		{
			printf("Pivot : %d\n", pivot);
			printf("Left Side : ");
			for (int a = p; a <= partition - 1; a++)
				printf("%d ", array[a]);

			printf("\nRight Side : ");
			for (int b = partition + 1; b <= q; b++)
				printf("%d ", array[b]);

			printf("\n\n");
		}

		// recursively Sub Quick Sort
		QuickSort_sub(array, p, partition - 1);
		QuickSort_sub(array, partition + 1, q);
	}

	return;
}