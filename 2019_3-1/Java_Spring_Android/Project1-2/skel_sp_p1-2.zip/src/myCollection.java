//package "your_project_name";

import java.util.*;

public class myCollection {

	//Collectiion
	private ArrayList<BookNode> al; 
	private LinkedList<BookNode> ll;
	private HashSet<BookNode> hs;
	private TreeSet<BookNode> ts;
	private HashMap<String, String> hm;	//Key : title, value : author
	private TreeMap<String, String> tm; //Key : title, value : author
	
	public myCollection(){

	}
	
	/*Push method*/
	public void addNode() {

	}
	/*Print method*/
	public String printNode() {
	
	}
	/*Search method*/
	public String searchNode() {
	
	}
	/*Update method*/
	public String updateNode() {
	
	}

}
