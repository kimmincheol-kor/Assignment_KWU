#include <stdio.h>

int main(void)
{
	int gold;
	
	while(gold<=27)
	{
		printf("%d", -gold);
		

	}
	return 0;
}