#include "Manager.h"
#include <iostream>
#include <fstream>

using namespace std;

int main(void)
{
	Manager manager; // declare Manager
	manager.run("command.txt"); // start run function of Manager

	return 0;
}