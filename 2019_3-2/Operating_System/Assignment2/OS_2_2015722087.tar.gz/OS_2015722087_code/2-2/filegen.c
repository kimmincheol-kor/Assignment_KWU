#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/types.h>

#define MAX_PROCESSES 30000

void main()
{
	FILE * write_temp;
	
	char filename[100];
	
	mkdir("temp",0776); // give all permission
    chdir("temp"); // change directory to temp
	
	for(int i=0; i<MAX_PROCESSES; i++)
	{
		srand(time(NULL)); // random value
		
		sprintf(filename, "%d", i); // file name = i
		
		write_temp = fopen(filename, "w"); // open file to write
	
		fprintf(write_temp, "%d\n", 1+rand()%9); // write random data (1~9) to file
		
		fclose(write_temp); // close file
	}
	
	return;
}