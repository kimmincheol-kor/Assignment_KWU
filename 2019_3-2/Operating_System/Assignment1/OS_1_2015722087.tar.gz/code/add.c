#include <linux/kernel.h>
#include <linux/syscalls.h>
#include <linux/unistd.h>

SYSCALL_DEFINE2(add, int, a, int, b) // this syscall have 2 parameter, int a, int b
{
        long result; // return value

        result = a + b; // add two parameter

        return result; // return result
}
