#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h>

void bubble(int a, int n, int list[]);

double total_time = 0.0;
long total_comparison = 0;

void main()
{
	int check = 0;
	int random;

	int list[5000]; // array of elements
	int n; // number of element
	int r; // number of repeat
	
	printf("Number of elements : ");
	scanf_s("%d", &n);

	printf("Number of repeats : ");
	scanf_s("%d", &r);

	for (int a = 0; a < r; a++)
	{
		Sleep(1000); // sleep for change srand
		srand(time(NULL));

		for (int a = 0; a < n; a++)
		{
			check = 0;
			random = rand(); // random number

			for (int b = 0; b < a; b++) // check duplication
			{
				if (list[b] == random) // duplication condition
					check++;
			}

			if (check != 0) // duplicate
				a--;
			else // not duplicate
				list[a] = random;
		}

		bubble(a + 1, n, list);
	}

	printf("\n\nAverage of Comparison : %ld \nAverage of actual Time : %f\n\n", total_comparison/r, (double)total_time/(double)r);
}

void bubble(int num_sort, int n, int list[])
{
	int check; // use at check complete sorting

	int temp; // use at swap
	int cycle = 1;

	int n_compare = 0;
	double run_time;

	// print list
	for (int a = 0; a < n; a++)
		printf("%d ", list[a]);
	printf("\n");

	LARGE_INTEGER startT, endT, fre; // check time

	QueryPerformanceFrequency(&fre); // frequency.
	QueryPerformanceCounter(&startT); // start time

	for (int i = n - 1; i > 0; i--) // repeat cycle (n-1) times
	{
		check = 0; // reset check

		for (int j = 0; j < i; j++) // sort 1 cycle
		{
			n_compare++;
			if (list[j] > list[j + 1]) // need swap
			{
				// swap
				temp = list[j];
				list[j] = list[j + 1];
				list[j + 1] = temp;

				// check
				check++;
			}
		}

		if (check == 0) // if check == 0, complete sort
			break;
	}
	QueryPerformanceCounter(&endT); // end time

	// print list
	for (int a = 0; a < n; a++)
		printf("%d ", list[a]);
	printf("\n");

	total_time += (double)(endT.QuadPart - startT.QuadPart) / fre.QuadPart;
	total_comparison += n_compare;
	printf("Number of Sorting : %d		Total comparison : %d		Running Time : %lf \n\n", num_sort, n_compare, (double)(endT.QuadPart - startT.QuadPart)/fre.QuadPart);
}