#include <stdio.h>

#define len_M 4
#define len_N 3

// function of compute LCS
void LCS(char str1[], char str2[], int i, int j);

// space for store compute
int space[len_N + 1][len_M + 1] = { NULL, };

void main()
{
	// two sequence
	char array_x[len_M] = { 'a','b','c','b'};
	char array_y[len_N] = { 'b','d','c'};

	printf("Bottom Up LCS ALGO\n\n");

	// set 0 line to zero.
	for (int a = 0; a <= len_M; a++)
	{
		space[0][a] = 0;
	}
	for (int b = 0; b <= len_N; b++)
	{
		space[b][0] = 0;
	}

	// Compute !
	LCS(array_x, array_y, len_M, len_N);


	printf("\nResult !!\n    ");

	for (int a = 0; a < len_M; a++)
	{
		printf("%c ", array_x[a]);
	}
	printf("\n");

	for (int a = 0; a < len_N + 1; a++) // column : array y
	{
		if (a != 0)
			printf("%c ", array_y[a - 1]);
		else
			printf("  ");

		for (int b = 0; b < len_M + 1; b++) // row : array x
		{
			printf("%d ", space[a][b]);
		}
		printf("\n");
	}

	// print LCS
	printf("\nLength of LCS = %d\n", space[len_N][len_M]);
}

void LCS(char str1[], char str2[], int i, int j)
{
	for (int a = 0; a < j; a++) // column element : array y
	{
		for (int b = 0; b < i; b++) // row element : array x
		{
			if (str1[b] == str2[a]) // if same, store previous data + 1 
				space[a + 1][b + 1] = space[a][b] + 1;
			else // if different, store max of above data, left data
				space[a + 1][b + 1] = space[a][b + 1] > space[a + 1][b] ? space[a][b + 1] : space[a + 1][b];

			printf("\ncompare => array_x[b] = %c, array_y[a] = %c\n    ", str1[b], str2[a]);

			for (int a = 0; a < i; a++)
			{
				printf("%c ", str1[a]);
			}
			printf("\n");

			for (int a = 0; a < len_N + 1; a++) // column : array y
			{
				if (a != 0)
					printf("%c ", str2[a - 1]);
				else
					printf("  ");
				for (int b = 0; b < len_M + 1; b++) // row : array x
				{
					printf("%d ", space[a][b]);
				}
				printf("\n");
			}
		}
	}
}